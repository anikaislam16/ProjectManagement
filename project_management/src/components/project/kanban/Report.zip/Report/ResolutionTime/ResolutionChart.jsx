import React, { useState, useEffect } from 'react';
import ReactApexChart from 'react-apexcharts';
import { useParams } from 'react-router-dom';
export default function ResolutionChart({ fromDate, toDate, period }) {
    const { projectId } = useParams();
    const categories = [];
    const currentDate = new Date(fromDate);
    console.log(fromDate, toDate, period);
    while (currentDate <= new Date(toDate)) {
        categories.push(currentDate.toISOString().split('T')[0]); // Format: 'YYYY-MM-DD'
        switch (period) {
            case 'daily':
                currentDate.setDate(currentDate.getDate() + 1);
                break;
            case 'weekly':
                currentDate.setDate(currentDate.getDate() + 7);
                break;
            case 'monthly':
                currentDate.setMonth(currentDate.getMonth() + 1);
                break;
            case 'quarterly':
                currentDate.setMonth(currentDate.getMonth() + 3);
                break;
            case 'yearly':
                currentDate.setFullYear(currentDate.getFullYear() + 1);
                break;
            default:
                break;
        }
    }
    console.log(categories);
    const data = [
        { date: '2022-03-01', resolvedIssue: 1, totalTime: 10 },
        { date: '2022-03-02', resolvedIssue: 2, totalTime: 15 },
        { date: '2022-03-03', resolvedIssue: 4, totalTime: 20 },
        // ... more data entries
    ];
    console.log(data)
    const [chartOptions, setChartOptions] = useState({
        chart: {
            type: 'bar',
            height: 350,
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '55%',
                endingShape: 'rounded',
            },
        },
        dataLabels: {
            enabled: false,
        },
        xaxis: {
            categories: data.map(item => item.date),
            labels: {
                formatter: function (val) {
                    const dateObject = new Date(val);
                    const options = { day: 'numeric', month: 'short', year: '2-digit' };
                    return dateObject.toLocaleDateString('en-US', options);
                },
            },
        },
        colors: '#06a306ea', // Red for non-resolved, Green for resolved
        yaxis: {
            title: {
                text: 'Average Time',
            },
            forceNiceScale: true,
        },
        fill: {
            opacity: 1,
        },
        tooltip: {
            y: {
                formatter: function (val) {
                    return val + ' issues'; ///eta pore change korbo....
                },
            },
        },
    });

    const [chartSeries, setChartSeries] = useState([]);
    useEffect(() => {
        setChartOptions((prevOptions) => ({
            ...prevOptions,
            xaxis: {
                ...prevOptions.xaxis,
                categories: data.map((item) => item.date),
            },
        }));

        const seriesData = [
            {
                name: 'Non-Resolved',
                data: data.map((item) => Math.round(item.totalTime / item.resolvedIssue)),
            },
        ];
        setChartSeries(seriesData);
    }, [data]); // Ensure that issues is the only dependency
    return <ReactApexChart options={chartOptions} series={chartSeries} type="bar" height={350} />;
};
